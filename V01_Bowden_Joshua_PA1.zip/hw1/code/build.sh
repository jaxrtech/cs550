#!/bin/bash
mvn package shade:shade
