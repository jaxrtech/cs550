package com.jaxrtech.bolt;

public enum BufferState {
    EMPTY, AGAIN, DONE
}
