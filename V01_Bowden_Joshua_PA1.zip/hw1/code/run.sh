#!/bin/bash
java -jar ./bolt-client/target/bolt-client-1.0-SNAPSHOT.jar
